import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'amf-form04',
  templateUrl: './form04.component.html',
  styleUrls: ['./form04.component.css']
})
export class Form04Component implements OnInit {
  // Variables para enlazar con los campos del formulario
  public userName: string;
  public userPass: string;
  public userConfirmPass: string;
  public selectedLanguages: string[];

  // Variables para determinar si hay errores en los campos del formulario
  public errorName = false;
  public errorPass = false;
  public errorConfirmPass = false;
  public errorLanguages = false;

  // Variables para determinar si se muestra mensaje de error o de OK, o ninguno
  public mensajeDeError = false;
  public mensajeDeOk = false;

  // Las opciones del selector mútiple de idiomas hablados.
  public spokenLanguages = [
    {
      value: 'es',
      text: 'Español'
    },
    {
      value: 'ca',
      text: 'Catalán'
    },
    {
      value: 'eu',
      text: 'Euskera'
    },
    {
      value: 'fr',
      text: 'Francés'
    },
    {
      value: 'en',
      text: 'Inglés'
    },
    {
      value: 'it',
      text: 'Italiano'
    },
    {
      value: 'de',
      text: 'Alemán'
    },
    {
      value: 'ro',
      text: 'Rumano'
    },
    {
      value: 'ru',
      text: 'Ruso'
    },
    {
      value: 'ch',
      text: 'Chino'
    },
    {
      value: 'jp',
      text: 'Japonés'
    }
  ];

  constructor() {}

  ngOnInit() {}

  checkForm() {
    this.errorName = (this.userName.length < 4);
    this.errorPass = (this.userPass.length < 6);
    this.errorConfirmPass = (this.userPass !== this.userConfirmPass);
    this.errorLanguages = (this.selectedLanguages === undefined || this.selectedLanguages.length < 3);
    this.mensajeDeError = (this.errorName ||
      this.errorPass ||
      this.errorConfirmPass ||
      this.errorLanguages);
    this.mensajeDeOk = (!this.mensajeDeError);
  }
}

